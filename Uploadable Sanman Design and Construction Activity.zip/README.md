# Twenty-Two Years — how to put this online

## Files

- `index.html`   the entire game. Self-contained: React is bundled in, nothing
                 is fetched from the internet. Open it by double-clicking and
                 it works, online or offline.
- `content.json` OPTIONAL. Your edited content. If this file sits next to
                 index.html on a web server, every visitor sees your version
                 instead of the built-in defaults.

## Publish it (about 30 seconds)

1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. You get a live URL. Share it. Your computer is not involved after this.

Create the free account when prompted, or the URL expires in a few hours.
Then Site settings -> Change site name to pick something readable.

Cloudflare Pages, GitHub Pages and Vercel all work identically.
Google Drive does NOT work — it no longer serves web pages.

## Edit the content, then publish your version

1. Open your live URL with ?edit=1 on the end:
       https://yoursite.netlify.app/?edit=1
2. Edit text, upload images.
3. Go to "Backup & reset" -> Export content JSON.
4. Rename the download to exactly  content.json
5. Put it in this folder and drag the folder onto Netlify Drop again.

Visitors without ?edit=1 never see the edit button.

## Running it with no internet at all

Copy index.html onto a USB stick and open it. Everything is embedded,
so it works with no connection. Useful for conference rooms with bad wifi.
Note that in this mode content.json is not read, so either publish it
online or make your edits on the machine you'll present from.
